#!/usr/bin/env python3
"""
Migra o dump MySQL/MariaDB `academico.sql` para o DynamoDB.

Uso:
  # 1) Ensaio (não precisa de AWS): lê o .sql, valida e gera JSONs em ./saida
  python migrar_academico.py --sql academico.sql

  # 2) Cria as tabelas e carrega os dados na AWS
  python migrar_academico.py --sql academico.sql --aws --regiao sa-east-1

  # 3) Idem, mas contra o DynamoDB Local (docker run -p 8000:8000 amazon/dynamodb-local)
  python migrar_academico.py --sql academico.sql --aws --endpoint-url http://localhost:8000

Requisitos para --aws:  pip install boto3  e credenciais configuradas (aws configure).
"""
import argparse
import json
import re
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# 1. Modelo DynamoDB (uma tabela SQL -> uma tabela DynamoDB)
#    pk/sk = (atributo, tipo)  |  gsis = (nome, (hash, tipo), (range, tipo) | None)
# ---------------------------------------------------------------------------
MODELO = {
    "alunos": {
        "tabela": "Alunos",
        "pk": ("ra", "N"),
        "sk": None,
        "gsis": [],
    },
    "cursos": {
        "tabela": "Cursos",
        "pk": ("idcurso", "N"),
        "sk": None,
        "gsis": [],
    },
    "professor": {
        "tabela": "Professores",
        "pk": ("idprofessor", "N"),
        "sk": None,
        "gsis": [],
    },
    "disciplina": {
        "tabela": "Disciplinas",
        "pk": ("iddisciplina", "N"),
        "sk": None,
        "gsis": [
            ("idcurso-index", ("idcurso", "N"), None),          # disciplinas de um curso
            ("idprofessor-index", ("idprofessor", "N"), None),  # disciplinas de um professor
        ],
    },
    "turma": {
        "tabela": "Turmas",
        "pk": ("idturma", "N"),
        "sk": None,
        "gsis": [
            ("iddisciplina-index", ("iddisciplina", "N"), None),  # turmas de uma disciplina
        ],
    },
    # `itemturma` (tabela associativa N:N) vira "Matriculas":
    # a chave natural (idturma, ra) substitui o iditem artificial.
    "itemturma": {
        "tabela": "Matriculas",
        "pk": ("idturma", "N"),   # Query: todos os alunos de uma turma
        "sk": ("ra", "N"),
        "gsis": [
            ("ra-index", ("ra", "N"), ("idturma", "N")),  # Query: todas as turmas de um aluno
        ],
    },
}

# Chaves estrangeiras do SQL (o DynamoDB não as impõe, então validamos antes de carregar)
FKS = [
    ("disciplina", "idcurso", "cursos"),
    ("disciplina", "idprofessor", "professor"),
    ("itemturma", "ra", "alunos"),
    ("itemturma", "idturma", "turma"),
    ("turma", "iddisciplina", "disciplina"),
]


# ---------------------------------------------------------------------------
# 2. Leitura do dump SQL
# ---------------------------------------------------------------------------
def parse_linhas(corpo):
    """Converte '(1,'a'),(2,'b')' em [[1,'a'],[2,'b']] respeitando aspas e escapes."""
    linhas, i, n = [], 0, len(corpo)
    while i < n:
        if corpo[i] != "(":
            i += 1
            continue
        i += 1
        linha = []
        while True:
            while corpo[i] in " \n\t\r":
                i += 1
            if corpo[i] == "'":
                i += 1
                buf = []
                while True:
                    c = corpo[i]
                    if c == "\\":
                        buf.append(corpo[i + 1])
                        i += 2
                    elif c == "'":
                        if corpo[i + 1] == "'":      # '' = aspa escapada
                            buf.append("'")
                            i += 2
                        else:
                            i += 1
                            break
                    else:
                        buf.append(c)
                        i += 1
                linha.append("".join(buf))
            else:
                j = i
                while corpo[j] not in ",)":
                    j += 1
                tok = corpo[i:j].strip()
                i = j
                if tok.upper() == "NULL":
                    linha.append(None)
                elif re.fullmatch(r"-?\d+", tok):
                    linha.append(int(tok))
                else:
                    linha.append(float(tok))
            while corpo[i] in " \n\t\r":
                i += 1
            if corpo[i] == ",":
                i += 1
                continue
            if corpo[i] == ")":
                i += 1
                break
        linhas.append(linha)
    return linhas


def ler_dump(caminho):
    sql = Path(caminho).read_text(encoding="utf-8")
    padrao = re.compile(
        r"INSERT INTO `(\w+)` \(([^)]*)\) VALUES\s*(.*?);\s*\n", re.DOTALL
    )
    dados = {}
    for m in padrao.finditer(sql):
        tabela = m.group(1)
        colunas = [c.strip().strip("`").lower() for c in m.group(2).split(",")]
        itens = []
        for linha in parse_linhas(m.group(3)):
            item = dict(zip(colunas, linha))
            # DynamoDB: atributos vazios/nulos são omitidos (itens "esparsos")
            itens.append({k: v for k, v in item.items() if v not in ("", None)})
        dados.setdefault(tabela, []).extend(itens)
    return dados


# ---------------------------------------------------------------------------
# 3. Validações
# ---------------------------------------------------------------------------
def validar(dados):
    erros = []
    for t, cfg in MODELO.items():
        if t not in dados:
            erros.append(f"Tabela '{t}' não encontrada no dump.")
            continue
        chaves = [cfg["pk"][0]] + ([cfg["sk"][0]] if cfg["sk"] else [])
        vistos = set()
        for item in dados[t]:
            chave = tuple(item.get(c) for c in chaves)
            if None in chave:
                erros.append(f"{t}: item sem chave {chaves}: {item}")
            if chave in vistos:
                erros.append(f"{t}: chave duplicada {chave}")
            vistos.add(chave)
    for origem, coluna, destino in FKS:
        pk_destino = MODELO[destino]["pk"][0]
        existentes = {i[pk_destino] for i in dados.get(destino, [])}
        for item in dados.get(origem, []):
            if item.get(coluna) not in existentes:
                erros.append(f"FK quebrada: {origem}.{coluna}={item.get(coluna)} -> {destino}")
    return erros


# ---------------------------------------------------------------------------
# 4. Saída em JSON (para conferência)
# ---------------------------------------------------------------------------
def gravar_json(dados, pasta):
    pasta = Path(pasta)
    pasta.mkdir(parents=True, exist_ok=True)
    for t, cfg in MODELO.items():
        destino = pasta / f"{cfg['tabela']}.json"
        destino.write_text(
            json.dumps(dados[t], ensure_ascii=False, indent=2), encoding="utf-8"
        )
        print(f"  {destino}  ({len(dados[t])} itens)")


# ---------------------------------------------------------------------------
# 5. Criação das tabelas e carga na AWS
# ---------------------------------------------------------------------------
def definicao_tabela(nome, cfg):
    attrs = {cfg["pk"][0]: cfg["pk"][1]}
    key_schema = [{"AttributeName": cfg["pk"][0], "KeyType": "HASH"}]
    if cfg["sk"]:
        attrs[cfg["sk"][0]] = cfg["sk"][1]
        key_schema.append({"AttributeName": cfg["sk"][0], "KeyType": "RANGE"})

    gsis = []
    for nome_idx, h, r in cfg["gsis"]:
        attrs[h[0]] = h[1]
        ks = [{"AttributeName": h[0], "KeyType": "HASH"}]
        if r:
            attrs[r[0]] = r[1]
            ks.append({"AttributeName": r[0], "KeyType": "RANGE"})
        gsis.append(
            {"IndexName": nome_idx, "KeySchema": ks, "Projection": {"ProjectionType": "ALL"}}
        )

    definicao = {
        "TableName": nome,
        "AttributeDefinitions": [
            {"AttributeName": a, "AttributeType": t} for a, t in attrs.items()
        ],
        "KeySchema": key_schema,
        "BillingMode": "PAY_PER_REQUEST",  # sob demanda: sem capacidade para dimensionar
    }
    if gsis:
        definicao["GlobalSecondaryIndexes"] = gsis
    return definicao


def carregar_na_aws(dados, regiao, endpoint, prefixo):
    try:
        import boto3
    except ImportError:
        sys.exit("boto3 não instalado. Rode: pip install boto3")

    ddb = boto3.resource("dynamodb", region_name=regiao, endpoint_url=endpoint)
    client = ddb.meta.client

    for t, cfg in MODELO.items():
        nome = prefixo + cfg["tabela"]
        try:
            ddb.create_table(**definicao_tabela(nome, cfg))
            print(f"  criando {nome} ...")
        except client.exceptions.ResourceInUseException:
            print(f"  {nome} já existe, reaproveitando.")
        client.get_waiter("table_exists").wait(TableName=nome)

        tabela = ddb.Table(nome)
        with tabela.batch_writer() as lote:  # agrupa em BatchWriteItem de até 25
            for item in dados[t]:
                lote.put_item(Item=item)
        print(f"  {nome}: {len(dados[t])} itens gravados")


# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    ap.add_argument("--sql", default="academico.sql", help="caminho do dump .sql")
    ap.add_argument("--saida", default="saida", help="pasta para os JSONs de conferência")
    ap.add_argument("--aws", action="store_true", help="cria as tabelas e carrega os dados")
    ap.add_argument("--regiao", default="sa-east-1")
    ap.add_argument("--endpoint-url", default=None, help="ex.: http://localhost:8000 (DynamoDB Local)")
    ap.add_argument("--prefixo", default="", help="prefixo dos nomes das tabelas, ex.: academico_")
    args = ap.parse_args()

    print("Lendo dump...")
    dados = ler_dump(args.sql)
    for t in MODELO:
        print(f"  {t}: {len(dados.get(t, []))} linhas")

    print("Validando...")
    erros = validar(dados)
    if erros:
        print("\n".join("  ERRO: " + e for e in erros))
        sys.exit(1)
    print("  ok (chaves únicas e chaves estrangeiras consistentes)")

    print("Gerando JSONs...")
    gravar_json(dados, args.saida)

    if args.aws:
        print("Enviando para o DynamoDB...")
        carregar_na_aws(dados, args.regiao, args.endpoint_url, args.prefixo)
    else:
        print("\nEnsaio concluído. Use --aws para criar as tabelas e carregar.")


if __name__ == "__main__":
    main()
