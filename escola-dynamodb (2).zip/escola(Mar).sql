-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 19/05/2026 às 21:01
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `escola`
--
CREATE DATABASE IF NOT EXISTS `escola` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `escola`;

-- --------------------------------------------------------

--
-- Estrutura para tabela `aluno`
--

CREATE TABLE `aluno` (
  `idAluno` int(11) NOT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `idade` int(11) DEFAULT NULL,
  `genero` varchar(20) DEFAULT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `endereco` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `aluno`
--

INSERT INTO `aluno` (`idAluno`, `nome`, `email`, `idade`, `genero`, `telefone`, `endereco`) VALUES
(1, 'Lucas Almeida', 'lucas.almeida@email.com', 15, 'Masculino', '11900000001', 'Rua 1'),
(2, 'Mariana Souza', 'mariana.souza@email.com', 16, 'Feminino', '11900000002', 'Rua 2'),
(3, 'Gabriel Santos', 'gabriel.santos@email.com', 15, 'Masculino', '11900000003', 'Rua 3'),
(4, 'Ana Oliveira', 'ana.oliveira@email.com', 16, 'Feminino', '11900000004', 'Rua 4'),
(5, 'Pedro Costa', 'pedro.costa@email.com', 15, 'Masculino', '11900000005', 'Rua 5'),
(6, 'Juliana Pereira', 'juliana.pereira@email.com', 16, 'Feminino', '11900000006', 'Rua 6'),
(7, 'Rafael Rodrigues', 'rafael.rodrigues@email.com', 15, 'Masculino', '11900000007', 'Rua 7'),
(8, 'Camila Ferreira', 'camila.ferreira@email.com', 16, 'Feminino', '11900000008', 'Rua 8'),
(9, 'Bruno Martins', 'bruno.martins@email.com', 15, 'Masculino', '11900000009', 'Rua 9'),
(10, 'Larissa Gomes', 'larissa.gomes@email.com', 16, 'Feminino', '11900000010', 'Rua 10'),
(11, 'Thiago Ribeiro', 'thiago.ribeiro@email.com', 15, 'Masculino', '11900000011', 'Rua 11'),
(12, 'Beatriz Alves', 'beatriz.alves@email.com', 16, 'Feminino', '11900000012', 'Rua 12'),
(13, 'Felipe Carvalho', 'felipe.carvalho@email.com', 15, 'Masculino', '11900000013', 'Rua 13'),
(14, 'Amanda Teixeira', 'amanda.teixeira@email.com', 16, 'Feminino', '11900000014', 'Rua 14'),
(15, 'Diego Moreira', 'diego.moreira@email.com', 15, 'Masculino', '11900000015', 'Rua 15'),
(16, 'Patricia Barbosa', 'patricia.barbosa@email.com', 16, 'Feminino', '11900000016', 'Rua 16'),
(17, 'Vinicius Cardoso', 'vinicius.cardoso@email.com', 15, 'Masculino', '11900000017', 'Rua 17'),
(18, 'Carla Mendes', 'carla.mendes@email.com', 16, 'Feminino', '11900000018', 'Rua 18'),
(19, 'Eduardo Nunes', 'eduardo.nunes@email.com', 15, 'Masculino', '11900000019', 'Rua 19'),
(20, 'Fernanda Freitas', 'fernanda.freitas@email.com', 16, 'Feminino', '11900000020', 'Rua 20'),
(21, 'Leonardo Rocha', 'leonardo.rocha@email.com', 15, 'Masculino', '11900000021', 'Rua 21'),
(22, 'Paula Dias', 'paula.dias@email.com', 16, 'Feminino', '11900000022', 'Rua 22'),
(23, 'Gustavo Monteiro', 'gustavo.monteiro@email.com', 15, 'Masculino', '11900000023', 'Rua 23'),
(24, 'Renata Araujo', 'renata.araujo@email.com', 16, 'Feminino', '11900000024', 'Rua 24'),
(25, 'Marcelo Castro', 'marcelo.castro@email.com', 15, 'Masculino', '11900000025', 'Rua 25'),
(26, 'Simone Pires', 'simone.pires@email.com', 16, 'Feminino', '11900000026', 'Rua 26'),
(27, 'André Farias', 'andre.farias@email.com', 15, 'Masculino', '11900000027', 'Rua 27'),
(28, 'Tatiane Lopes', 'tatiane.lopes@email.com', 16, 'Feminino', '11900000028', 'Rua 28'),
(29, 'Rodrigo Batista', 'rodrigo.batista@email.com', 15, 'Masculino', '11900000029', 'Rua 29'),
(30, 'Vanessa Ramos', 'vanessa.ramos@email.com', 16, 'Feminino', '11900000030', 'Rua 30'),
(31, 'Igor Moura', 'igor.moura@email.com', 15, 'Masculino', '11900000031', 'Rua 31'),
(32, 'Daniela Duarte', 'daniela.duarte@email.com', 16, 'Feminino', '11900000032', 'Rua 32'),
(33, 'Caio Antunes', 'caio.antunes@email.com', 15, 'Masculino', '11900000033', 'Rua 33'),
(34, 'Priscila Neves', 'priscila.neves@email.com', 16, 'Feminino', '11900000034', 'Rua 34'),
(35, 'Henrique Paiva', 'henrique.paiva@email.com', 15, 'Masculino', '11900000035', 'Rua 35'),
(36, 'Julio Cesar', 'julio.cesar@email.com', 16, 'Masculino', '11900000036', 'Rua 36'),
(37, 'Elaine Peixoto', 'elaine.peixoto@email.com', 16, 'Feminino', '11900000037', 'Rua 37'),
(38, 'Ricardo Viana', 'ricardo.viana@email.com', 15, 'Masculino', '11900000038', 'Rua 38'),
(39, 'Sandra Queiroz', 'sandra.queiroz@email.com', 16, 'Feminino', '11900000039', 'Rua 39'),
(40, 'Alan Correia', 'alan.correia@email.com', 15, 'Masculino', '11900000040', 'Rua 40'),
(41, 'Roberta Cunha', 'roberta.cunha@email.com', 16, 'Feminino', '11900000041', 'Rua 41'),
(42, 'Paulo Borges', 'paulo.borges@email.com', 15, 'Masculino', '11900000042', 'Rua 42'),
(43, 'Michele Matos', 'michele.matos@email.com', 16, 'Feminino', '11900000043', 'Rua 43'),
(44, 'Douglas Tavares', 'douglas.tavares@email.com', 15, 'Masculino', '11900000044', 'Rua 44'),
(45, 'Aline Macedo', 'aline.macedo@email.com', 16, 'Feminino', '11900000045', 'Rua 45'),
(46, 'Fernando Rezende', 'fernando.rezende@email.com', 15, 'Masculino', '11900000046', 'Rua 46'),
(47, 'Bianca Guedes', 'bianca.guedes@email.com', 16, 'Feminino', '11900000047', 'Rua 47'),
(48, 'Sergio Azevedo', 'sergio.azevedo@email.com', 15, 'Masculino', '11900000048', 'Rua 48'),
(49, 'Kelly Franco', 'kelly.franco@email.com', 16, 'Feminino', '11900000049', 'Rua 49'),
(50, 'Victor Amaral', 'victor.amaral@email.com', 15, 'Masculino', '11900000050', 'Rua 50'),
(51, 'Natalia Rangel', 'natalia.rangel@email.com', 16, 'Feminino', '11900000051', 'Rua 51'),
(52, 'Bruno Leite', 'bruno.leite@email.com', 15, 'Masculino', '11900000052', 'Rua 52'),
(53, 'Leticia Porto', 'leticia.porto@email.com', 16, 'Feminino', '11900000053', 'Rua 53'),
(54, 'Fábio Lemos', 'fabio.lemos@email.com', 15, 'Masculino', '11900000054', 'Rua 54'),
(55, 'Cintia Mota', 'cintia.mota@email.com', 16, 'Feminino', '11900000055', 'Rua 55'),
(56, 'Rogério Sales', 'rogerio.sales@email.com', 15, 'Masculino', '11900000056', 'Rua 56'),
(57, 'Luciana Figueiredo', 'luciana.figueiredo@email.com', 16, 'Feminino', '11900000057', 'Rua 57'),
(58, 'Wesley Brandão', 'wesley.brandao@email.com', 15, 'Masculino', '11900000058', 'Rua 58'),
(59, 'Adriana Pontes', 'adriana.pontes@email.com', 16, 'Feminino', '11900000059', 'Rua 59'),
(60, 'João Vitor', 'joao.vitor@email.com', 15, 'Masculino', '11900000060', 'Rua 60'),
(61, 'Marcela Torres', 'marcela.torres@email.com', 16, 'Feminino', '11900000061', 'Rua 61'),
(62, 'Elias Fonseca', 'elias.fonseca@email.com', 15, 'Masculino', '11900000062', 'Rua 62'),
(63, 'Raquel Xavier', 'raquel.xavier@email.com', 16, 'Feminino', '11900000063', 'Rua 63'),
(64, 'Samuel Teodoro', 'samuel.teodoro@email.com', 15, 'Masculino', '11900000064', 'Rua 64'),
(65, 'Claudia Santana', 'claudia.santana@email.com', 16, 'Feminino', '11900000065', 'Rua 65'),
(66, 'Hugo Medeiros', 'hugo.medeiros@email.com', 15, 'Masculino', '11900000066', 'Rua 66'),
(67, 'Patricia Veloso', 'patricia.veloso@email.com', 16, 'Feminino', '11900000067', 'Rua 67'),
(68, 'Alex Sandro', 'alex.sandro@email.com', 15, 'Masculino', '11900000068', 'Rua 68'),
(69, 'Denise Furtado', 'denise.furtado@email.com', 16, 'Feminino', '11900000069', 'Rua 69'),
(70, 'Otavio Peçanha', 'otavio.pecanha@email.com', 15, 'Masculino', '11900000070', 'Rua 70'),
(71, 'Flavia Nogueira', 'flavia.nogueira@email.com', 16, 'Feminino', '11900000071', 'Rua 71'),
(72, 'Eduardo Braga', 'eduardo.braga@email.com', 15, 'Masculino', '11900000072', 'Rua 72'),
(73, 'Carolina Teles', 'carolina.teles@email.com', 16, 'Feminino', '11900000073', 'Rua 73'),
(74, 'Renan Guimarães', 'renan.guimaraes@email.com', 15, 'Masculino', '11900000074', 'Rua 74'),
(75, 'Tatiana Borges', 'tatiana.borges@email.com', 16, 'Feminino', '11900000075', 'Rua 75'),
(76, 'Guilherme Pacheco', 'guilherme.pacheco@email.com', 15, 'Masculino', '11900000076', 'Rua 76'),
(77, 'Monica Barros', 'monica.barros@email.com', 16, 'Feminino', '11900000077', 'Rua 77'),
(78, 'Daniel Rocha', 'daniel.rocha@email.com', 15, 'Masculino', '11900000078', 'Rua 78'),
(79, 'Patricia Costa', 'patricia.costa@email.com', 16, 'Feminino', '11900000079', 'Rua 79'),
(80, 'Lucas Vieira', 'lucas.vieira@email.com', 15, 'Masculino', '11900000080', 'Rua 80'),
(81, 'Bruna Sales', 'bruna.sales@email.com', 16, 'Feminino', '11900000081', 'Rua 81'),
(82, 'Thiago Cunha', 'thiago.cunha@email.com', 15, 'Masculino', '11900000082', 'Rua 82'),
(83, 'Amanda Nascimento', 'amanda.nascimento@email.com', 16, 'Feminino', '11900000083', 'Rua 83'),
(84, 'Rafael Peixoto', 'rafael.peixoto@email.com', 15, 'Masculino', '11900000084', 'Rua 84'),
(85, 'Carla Rezende', 'carla.rezende@email.com', 16, 'Feminino', '11900000085', 'Rua 85'),
(86, 'Vinicius Lopes', 'vinicius.lopes@email.com', 15, 'Masculino', '11900000086', 'Rua 86'),
(87, 'Juliana Batista', 'juliana.batista@email.com', 16, 'Feminino', '11900000087', 'Rua 87'),
(88, 'Felipe Duarte', 'felipe.duarte@email.com', 15, 'Masculino', '11900000088', 'Rua 88'),
(89, 'Renata Gomes', 'renata.gomes@email.com', 16, 'Feminino', '11900000089', 'Rua 89'),
(90, 'Pedro Henrique', 'pedro.henrique@email.com', 15, 'Masculino', '11900000090', 'Rua 90'),
(91, 'Aline Cardoso', 'aline.cardoso@email.com', 16, 'Feminino', '11900000091', 'Rua 91'),
(92, 'Gustavo Rocha', 'gustavo.rocha@email.com', 15, 'Masculino', '11900000092', 'Rua 92'),
(93, 'Fernanda Lima', 'fernanda.lima@email.com', 16, 'Feminino', '11900000093', 'Rua 93'),
(94, 'Diego Martins', 'diego.martins@email.com', 15, 'Masculino', '11900000094', 'Rua 94'),
(95, 'Patricia Alves', 'patricia.alves@email.com', 16, 'Feminino', '11900000095', 'Rua 95'),
(96, 'Rodrigo Costa', 'rodrigo.costa@email.com', 15, 'Masculino', '11900000096', 'Rua 96'),
(97, 'Camila Ribeiro', 'camila.ribeiro@email.com', 16, 'Feminino', '11900000097', 'Rua 97'),
(98, 'Bruno Freitas', 'bruno.freitas@email.com', 15, 'Masculino', '11900000098', 'Rua 98'),
(99, 'Mariana Duarte', 'mariana.duarte@email.com', 16, 'Feminino', '11900000099', 'Rua 99'),
(100, 'Lucas Nogueira', 'lucas.nogueira@email.com', 15, 'Masculino', '11900000100', 'Rua 100');

-- --------------------------------------------------------

--
-- Estrutura para tabela `aluno_turma`
--

CREATE TABLE `aluno_turma` (
  `idAluno` int(11) NOT NULL,
  `idTurma` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `aluno_turma`
--

INSERT INTO `aluno_turma` (`idAluno`, `idTurma`) VALUES
(1, 2),
(1, 3),
(1, 4),
(1, 5),
(2, 3),
(2, 4),
(2, 5),
(2, 6),
(3, 4),
(3, 5),
(3, 6),
(3, 7),
(4, 5),
(4, 6),
(4, 7),
(4, 8),
(5, 6),
(5, 7),
(5, 8),
(5, 9),
(6, 7),
(6, 8),
(6, 9),
(6, 10),
(7, 8),
(7, 9),
(7, 10),
(7, 11),
(8, 9),
(8, 10),
(8, 11),
(8, 12),
(9, 10),
(9, 11),
(9, 12),
(9, 13),
(10, 11),
(10, 12),
(10, 13),
(10, 14),
(11, 12),
(11, 13),
(11, 14),
(11, 15),
(12, 13),
(12, 14),
(12, 15),
(12, 16),
(13, 14),
(13, 15),
(13, 16),
(13, 17),
(14, 15),
(14, 16),
(14, 17),
(14, 18),
(15, 16),
(15, 17),
(15, 18),
(15, 19),
(16, 17),
(16, 18),
(16, 19),
(16, 20),
(17, 18),
(17, 19),
(17, 20),
(17, 21),
(18, 19),
(18, 20),
(18, 21),
(18, 22),
(19, 20),
(19, 21),
(19, 22),
(19, 23),
(20, 21),
(20, 22),
(20, 23),
(20, 24),
(21, 22),
(21, 23),
(21, 24),
(21, 25),
(22, 1),
(22, 23),
(22, 24),
(22, 25),
(23, 1),
(23, 2),
(23, 24),
(23, 25),
(24, 1),
(24, 2),
(24, 3),
(24, 25),
(25, 1),
(25, 2),
(25, 3),
(25, 4),
(26, 2),
(26, 3),
(26, 4),
(26, 5),
(27, 3),
(27, 4),
(27, 5),
(27, 6),
(28, 4),
(28, 5),
(28, 6),
(28, 7),
(29, 5),
(29, 6),
(29, 7),
(29, 8),
(30, 6),
(30, 7),
(30, 8),
(30, 9),
(31, 7),
(31, 8),
(31, 9),
(31, 10),
(32, 8),
(32, 9),
(32, 10),
(32, 11),
(33, 9),
(33, 10),
(33, 11),
(33, 12),
(34, 10),
(34, 11),
(34, 12),
(34, 13),
(35, 11),
(35, 12),
(35, 13),
(35, 14),
(36, 12),
(36, 13),
(36, 14),
(36, 15),
(37, 13),
(37, 14),
(37, 15),
(37, 16),
(38, 14),
(38, 15),
(38, 16),
(38, 17),
(39, 15),
(39, 16),
(39, 17),
(39, 18),
(40, 16),
(40, 17),
(40, 18),
(40, 19),
(41, 17),
(41, 18),
(41, 19),
(41, 20),
(42, 18),
(42, 19),
(42, 20),
(42, 21),
(43, 19),
(43, 20),
(43, 21),
(43, 22),
(44, 20),
(44, 21),
(44, 22),
(44, 23),
(45, 21),
(45, 22),
(45, 23),
(45, 24),
(46, 22),
(46, 23),
(46, 24),
(46, 25),
(47, 1),
(47, 23),
(47, 24),
(47, 25),
(48, 1),
(48, 2),
(48, 24),
(48, 25),
(49, 1),
(49, 2),
(49, 3),
(49, 25),
(50, 1),
(50, 2),
(50, 3),
(50, 4),
(51, 2),
(51, 3),
(51, 4),
(51, 5),
(52, 3),
(52, 4),
(52, 5),
(52, 6),
(53, 4),
(53, 5),
(53, 6),
(53, 7),
(54, 5),
(54, 6),
(54, 7),
(54, 8),
(55, 6),
(55, 7),
(55, 8),
(55, 9),
(56, 7),
(56, 8),
(56, 9),
(56, 10),
(57, 8),
(57, 9),
(57, 10),
(57, 11),
(58, 9),
(58, 10),
(58, 11),
(58, 12),
(59, 10),
(59, 11),
(59, 12),
(59, 13),
(60, 11),
(60, 12),
(60, 13),
(60, 14),
(61, 12),
(61, 13),
(61, 14),
(61, 15),
(62, 13),
(62, 14),
(62, 15),
(62, 16),
(63, 14),
(63, 15),
(63, 16),
(63, 17),
(64, 15),
(64, 16),
(64, 17),
(64, 18),
(65, 16),
(65, 17),
(65, 18),
(65, 19),
(66, 17),
(66, 18),
(66, 19),
(66, 20),
(67, 18),
(67, 19),
(67, 20),
(67, 21),
(68, 19),
(68, 20),
(68, 21),
(68, 22),
(69, 20),
(69, 21),
(69, 22),
(69, 23),
(70, 21),
(70, 22),
(70, 23),
(70, 24),
(71, 22),
(71, 23),
(71, 24),
(71, 25),
(72, 1),
(72, 23),
(72, 24),
(72, 25),
(73, 1),
(73, 2),
(73, 24),
(73, 25),
(74, 1),
(74, 2),
(74, 3),
(74, 25),
(75, 1),
(75, 2),
(75, 3),
(75, 4),
(76, 2),
(76, 3),
(76, 4),
(76, 5),
(77, 3),
(77, 4),
(77, 5),
(77, 6),
(78, 4),
(78, 5),
(78, 6),
(78, 7),
(79, 5),
(79, 6),
(79, 7),
(79, 8),
(80, 6),
(80, 7),
(80, 8),
(80, 9),
(81, 7),
(81, 8),
(81, 9),
(81, 10),
(82, 8),
(82, 9),
(82, 10),
(82, 11),
(83, 9),
(83, 10),
(83, 11),
(83, 12),
(84, 10),
(84, 11),
(84, 12),
(84, 13),
(85, 11),
(85, 12),
(85, 13),
(85, 14),
(86, 12),
(86, 13),
(86, 14),
(86, 15),
(87, 13),
(87, 14),
(87, 15),
(87, 16),
(88, 14),
(88, 15),
(88, 16),
(88, 17),
(89, 15),
(89, 16),
(89, 17),
(89, 18),
(90, 16),
(90, 17),
(90, 18),
(90, 19),
(91, 17),
(91, 18),
(91, 19),
(91, 20),
(92, 18),
(92, 19),
(92, 20),
(92, 21),
(93, 19),
(93, 20),
(93, 21),
(93, 22),
(94, 20),
(94, 21),
(94, 22),
(94, 23),
(95, 21),
(95, 22),
(95, 23),
(95, 24),
(96, 22),
(96, 23),
(96, 24),
(96, 25),
(97, 1),
(97, 23),
(97, 24),
(97, 25),
(98, 1),
(98, 2),
(98, 24),
(98, 25),
(99, 1),
(99, 2),
(99, 3),
(99, 25),
(100, 1),
(100, 2),
(100, 3),
(100, 4);

-- --------------------------------------------------------

--
-- Estrutura para tabela `disciplina`
--

CREATE TABLE `disciplina` (
  `idDisciplina` int(11) NOT NULL,
  `nome` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `disciplina`
--

INSERT INTO `disciplina` (`idDisciplina`, `nome`) VALUES
(1, 'Matemática'),
(2, 'Português'),
(3, 'História'),
(4, 'Geografia'),
(5, 'Física'),
(6, 'Química'),
(7, 'Biologia'),
(8, 'Inglês'),
(9, 'Artes'),
(10, 'Educação Física');

-- --------------------------------------------------------

--
-- Estrutura para tabela `professor`
--

CREATE TABLE `professor` (
  `idProfessor` int(11) NOT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `endereco` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `professor`
--

INSERT INTO `professor` (`idProfessor`, `nome`, `email`, `telefone`, `endereco`) VALUES
(1, 'Professor 1', 'p1@email.com', '11900000001', 'Rua 1'),
(2, 'Professor 2', 'p2@email.com', '11900000002', 'Rua 2'),
(3, 'Professor 3', 'p3@email.com', '11900000003', 'Rua 3'),
(4, 'Professor 4', 'p4@email.com', '11900000004', 'Rua 4'),
(5, 'Professor 5', 'p5@email.com', '11900000005', 'Rua 5'),
(6, 'Professor 6', 'p6@email.com', '11900000006', 'Rua 6'),
(7, 'Professor 7', 'p7@email.com', '11900000007', 'Rua 7'),
(8, 'Professor 8', 'p8@email.com', '11900000008', 'Rua 8'),
(9, 'Professor 9', 'p9@email.com', '11900000009', 'Rua 9'),
(10, 'Professor 10', 'p10@email.com', '11900000010', 'Rua 10'),
(11, 'Professor 11', 'p11@email.com', '11900000011', 'Rua 11'),
(12, 'Professor 12', 'p12@email.com', '11900000012', 'Rua 12'),
(13, 'Professor 13', 'p13@email.com', '11900000013', 'Rua 13'),
(14, 'Professor 14', 'p14@email.com', '11900000014', 'Rua 14'),
(15, 'Professor 15', 'p15@email.com', '11900000015', 'Rua 15'),
(16, 'Professor 16', 'p16@email.com', '11900000016', 'Rua 16'),
(17, 'Professor 17', 'p17@email.com', '11900000017', 'Rua 17'),
(18, 'Professor 18', 'p18@email.com', '11900000018', 'Rua 18'),
(19, 'Professor 19', 'p19@email.com', '11900000019', 'Rua 19'),
(20, 'Professor 20', 'p20@email.com', '11900000020', 'Rua 20'),
(21, 'Professor 21', 'p21@email.com', '11900000021', 'Rua 21'),
(22, 'Professor 22', 'p22@email.com', '11900000022', 'Rua 22'),
(23, 'Professor 23', 'p23@email.com', '11900000023', 'Rua 23'),
(24, 'Professor 24', 'p24@email.com', '11900000024', 'Rua 24'),
(25, 'Professor 25', 'p25@email.com', '11900000025', 'Rua 25');

-- --------------------------------------------------------

--
-- Estrutura para tabela `professor_disciplina`
--

CREATE TABLE `professor_disciplina` (
  `idProfessor` int(11) NOT NULL,
  `idDisciplina` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `professor_disciplina`
--

INSERT INTO `professor_disciplina` (`idProfessor`, `idDisciplina`) VALUES
(1, 1),
(1, 5),
(2, 2),
(2, 6),
(3, 3),
(3, 7),
(4, 4),
(4, 8),
(5, 5),
(5, 9),
(6, 6),
(6, 10),
(7, 1),
(7, 7),
(8, 2),
(8, 8),
(9, 3),
(9, 9),
(10, 4),
(10, 10),
(11, 1),
(11, 5),
(12, 2),
(12, 6),
(13, 3),
(13, 7),
(14, 4),
(14, 8),
(15, 5),
(15, 9),
(16, 6),
(16, 10),
(17, 1),
(17, 7),
(18, 2),
(18, 8),
(19, 3),
(19, 9),
(20, 4),
(20, 10),
(21, 1),
(21, 5),
(22, 2),
(22, 6),
(23, 3),
(23, 7),
(24, 4),
(24, 8),
(25, 5),
(25, 9);

-- --------------------------------------------------------

--
-- Estrutura para tabela `turma`
--

CREATE TABLE `turma` (
  `idTurma` int(11) NOT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `ano` int(4) NOT NULL,
  `semestre` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `turma`
--

INSERT INTO `turma` (`idTurma`, `nome`, `ano`, `semestre`) VALUES
(26, 'ADS-A', 2024, 1),
(27, 'ADS-A', 2024, 2),
(28, 'ADS-B', 2024, 1),
(29, 'ADS-B', 2024, 2),
(32, 'ENG-A', 2025, 1),
(33, 'ENG-A', 2025, 2),
(30, 'INFO-A', 2025, 1),
(31, 'INFO-A', 2025, 2),
(34, 'MAT-A', 2023, 1),
(35, 'MAT-A', 2023, 2),
(1, 'Turma 1', 2001, 1),
(10, 'Turma 10', 2010, 2),
(11, 'Turma 11', 0, 0),
(12, 'Turma 12', 0, 0),
(13, 'Turma 13', 0, 0),
(14, 'Turma 14', 0, 0),
(15, 'Turma 15', 0, 0),
(16, 'Turma 16', 0, 0),
(17, 'Turma 17', 0, 0),
(18, 'Turma 18', 0, 0),
(19, 'Turma 19', 0, 0),
(2, 'Turma 2', 2002, 1),
(20, 'Turma 20', 0, 0),
(21, 'Turma 21', 0, 0),
(22, 'Turma 22', 0, 0),
(23, 'Turma 23', 0, 0),
(24, 'Turma 24', 0, 0),
(25, 'Turma 25', 0, 0),
(3, 'Turma 3', 2003, 1),
(4, 'Turma 4', 2004, 1),
(5, 'Turma 5', 2005, 1),
(6, 'Turma 6', 2006, 2),
(7, 'Turma 7', 2007, 2),
(8, 'Turma 8', 2008, 2),
(9, 'Turma 9', 2009, 2);

-- --------------------------------------------------------

--
-- Estrutura para tabela `turma_disciplina`
--

CREATE TABLE `turma_disciplina` (
  `idTurma` int(11) NOT NULL,
  `idDisciplina` int(11) NOT NULL,
  `idProfessor` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `turma_disciplina`
--

INSERT INTO `turma_disciplina` (`idTurma`, `idDisciplina`, `idProfessor`) VALUES
(24, 6, 1),
(25, 6, 1),
(1, 2, 2),
(25, 7, 2),
(1, 3, 3),
(2, 3, 3),
(2, 4, 4),
(3, 4, 4),
(3, 5, 5),
(4, 5, 5),
(4, 6, 6),
(5, 6, 6),
(5, 7, 7),
(6, 7, 7),
(6, 8, 8),
(7, 8, 8),
(7, 9, 9),
(8, 9, 9),
(8, 10, 10),
(9, 10, 10),
(9, 1, 11),
(10, 1, 11),
(10, 2, 12),
(11, 2, 12),
(11, 3, 13),
(12, 3, 13),
(12, 4, 14),
(13, 4, 14),
(13, 5, 15),
(14, 5, 15),
(14, 6, 16),
(15, 6, 16),
(15, 7, 17),
(16, 7, 17),
(16, 8, 18),
(17, 8, 18),
(17, 9, 19),
(18, 9, 19),
(18, 10, 20),
(19, 10, 20),
(19, 1, 21),
(20, 1, 21),
(20, 2, 22),
(21, 2, 22),
(21, 3, 23),
(22, 3, 23),
(22, 4, 24),
(23, 4, 24),
(23, 5, 25),
(24, 5, 25);

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `aluno`
--
ALTER TABLE `aluno`
  ADD PRIMARY KEY (`idAluno`);

--
-- Índices de tabela `aluno_turma`
--
ALTER TABLE `aluno_turma`
  ADD PRIMARY KEY (`idAluno`,`idTurma`),
  ADD KEY `idTurma` (`idTurma`);

--
-- Índices de tabela `disciplina`
--
ALTER TABLE `disciplina`
  ADD PRIMARY KEY (`idDisciplina`);

--
-- Índices de tabela `professor`
--
ALTER TABLE `professor`
  ADD PRIMARY KEY (`idProfessor`);

--
-- Índices de tabela `professor_disciplina`
--
ALTER TABLE `professor_disciplina`
  ADD PRIMARY KEY (`idProfessor`,`idDisciplina`),
  ADD KEY `idDisciplina` (`idDisciplina`);

--
-- Índices de tabela `turma`
--
ALTER TABLE `turma`
  ADD PRIMARY KEY (`idTurma`),
  ADD UNIQUE KEY `unique_turma_periodo` (`nome`,`ano`,`semestre`),
  ADD KEY `idx_turma_ano` (`ano`),
  ADD KEY `idx_turma_semestre` (`semestre`);

--
-- Índices de tabela `turma_disciplina`
--
ALTER TABLE `turma_disciplina`
  ADD PRIMARY KEY (`idTurma`,`idDisciplina`),
  ADD KEY `idDisciplina` (`idDisciplina`),
  ADD KEY `idProfessor` (`idProfessor`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `aluno`
--
ALTER TABLE `aluno`
  MODIFY `idAluno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT de tabela `disciplina`
--
ALTER TABLE `disciplina`
  MODIFY `idDisciplina` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de tabela `professor`
--
ALTER TABLE `professor`
  MODIFY `idProfessor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT de tabela `turma`
--
ALTER TABLE `turma`
  MODIFY `idTurma` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `aluno_turma`
--
ALTER TABLE `aluno_turma`
  ADD CONSTRAINT `aluno_turma_ibfk_1` FOREIGN KEY (`idAluno`) REFERENCES `aluno` (`idAluno`) ON DELETE CASCADE,
  ADD CONSTRAINT `aluno_turma_ibfk_2` FOREIGN KEY (`idTurma`) REFERENCES `turma` (`idTurma`) ON DELETE CASCADE;

--
-- Restrições para tabelas `professor_disciplina`
--
ALTER TABLE `professor_disciplina`
  ADD CONSTRAINT `professor_disciplina_ibfk_1` FOREIGN KEY (`idProfessor`) REFERENCES `professor` (`idProfessor`) ON DELETE CASCADE,
  ADD CONSTRAINT `professor_disciplina_ibfk_2` FOREIGN KEY (`idDisciplina`) REFERENCES `disciplina` (`idDisciplina`) ON DELETE CASCADE;

--
-- Restrições para tabelas `turma_disciplina`
--
ALTER TABLE `turma_disciplina`
  ADD CONSTRAINT `turma_disciplina_ibfk_1` FOREIGN KEY (`idTurma`) REFERENCES `turma` (`idTurma`) ON DELETE CASCADE,
  ADD CONSTRAINT `turma_disciplina_ibfk_2` FOREIGN KEY (`idDisciplina`) REFERENCES `disciplina` (`idDisciplina`) ON DELETE CASCADE,
  ADD CONSTRAINT `turma_disciplina_ibfk_3` FOREIGN KEY (`idProfessor`) REFERENCES `professor` (`idProfessor`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
